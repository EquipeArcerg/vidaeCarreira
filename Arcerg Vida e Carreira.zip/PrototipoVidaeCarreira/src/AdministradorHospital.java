
public class AdministradorHospital extends Funcionario{

}
