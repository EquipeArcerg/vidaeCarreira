
import java.util.Scanner;

public class CodigoFonte {

	private static boolean logouPaciente;
	private static boolean logouHospital;
	private static boolean saiu;
	private static String hospitalEscolhido;

	public static void main(String[] args) {

		SistemaInterno sistemaInterno = new SistemaInterno();
		Hospital hospitalFelicioRocho = new Hospital("111.222.333-45", "HospitalFelicioRocho", "F3L1ci0R0x9", "amem",
				"30110-934");
		sistemaInterno.adicionarHospital(hospitalFelicioRocho);
		Hospital hospitalEduardoDeMenezes = new Hospital("100.200.300-40", "HospitalEduardoDeMenezes", "3D9@rD0M#N#zes",
				"issoai", "30622-020");
		sistemaInterno.adicionarHospital(hospitalEduardoDeMenezes);

		while (logouPaciente != true || saiu != true || logouHospital != true) {

			sistemaInterno.cabecalho();

			System.out.println("Seja bem-vindo!");
			System.out.println("O que voc� deseja fazer?");
			System.out.println("Digite 1 para cadastrar-se");
			System.out.println("Digite 2 para fazer login");
			System.out.println("Digite 3 para exibir lista de pacientes");
			System.out.println("Digite 4 para sair");

			System.out.println();

			Scanner scanner = new Scanner(System.in);
			System.out.println();
			String decisao = scanner.nextLine();

			sistemaInterno.metodoEscolhas(decisao);

			if (decisao.equals("1")) {

				System.out.print("Por favor, insira o CPF: ");
				String cpf = scanner.nextLine();

				System.out.print("Agora, por favor, insira o nome completo: ");
				String nome = scanner.nextLine();

				System.out.print("Insira agora a senha que deseja registrar: ");
				String senha = scanner.nextLine();

				System.out.print("Insira agora a data de nascimento que deseja registrar: ");
				String dataDeNascimento = scanner.nextLine();

				sistemaInterno.adicionarPaciente(new Paciente(cpf, nome, senha, dataDeNascimento));

			} else if (decisao.equals("2")) {

				System.out.println("Voc� deseja fazer login como: ");
				System.out.println("1 - Paciente");
				System.out.println("2 - Hospital");
				System.out.println();
				System.out.println();
				String login = scanner.nextLine();

				if (login.equals("1")) {

					System.out.print("Por favor insira seu CPF: ");
					String cpf = scanner.nextLine();
					System.out.print("Agora, insira sua senha: ");
					String senha = scanner.nextLine();

					if (sistemaInterno.login(cpf, senha) == true) {
						System.out.println("Sucesso!");
						System.out.println();
						logouPaciente = true;
						break;
					} else {
						System.out.println("Erro, paciente n�o encontrado");

					}

				}
				if (login.equals("2")) {

					System.out.print("Por favor insira seu Cnpj: ");
					String cnpj = scanner.nextLine();

					System.out.print("Agora, insira sua senha insitucional: ");
					String senhaInstitucional = scanner.nextLine();

					System.out.println("Insira aqui a senha pessoal do respons�vel geral: ");
					String senhaPessoalDoRespons�vel = scanner.nextLine();

					sistemaInterno.loginHospital(cnpj, senhaInstitucional, senhaPessoalDoRespons�vel);

					if (sistemaInterno.loginHospital(cnpj, senhaInstitucional, senhaPessoalDoRespons�vel) == true) {
						System.out.println("Sucesso!");
						System.out.println();
						logouHospital = true;
						break;
					} else {
						System.out.println("Erro, hospital n�o encontrado");

					}

				}
			} else if (decisao.equals("3")) {
				sistemaInterno.getListPaciente();

			} else if (decisao.equals("4")) {
				System.out.println("Muito obrigado por usar nosso sistema.");
				saiu = true;
				break;
			}

			else {
				System.out.println("Op��o inv�lida, selecione corretamente uma op��o.");

			}

		}

		if (logouPaciente == true) {
			String decisao;
			saiu = false;
			while (saiu != true) {
				sistemaInterno.cabecalho();
				sistemaInterno.boasVindasPaciente();
				sistemaInterno.telaPrincipalPaciente();

				Scanner scanner = new Scanner(System.in);
				decisao = scanner.nextLine();

				sistemaInterno.metodoEscolhas(decisao);
				switch (decisao) {

				case "1":

					while (true) {
						sistemaInterno.getListHospitais();
						System.out.println();
						System.out.println();
						System.out.println("O que deseja fazer?");
						System.out.println();
						System.out.println("1- Escolher uma unidade e entrar na fila de espera");
						System.out.println("2- Voltar");
						String escolha = scanner.nextLine();

						if (escolha.equals("1")) {
							System.out.println(
							"Digite o nome da unidade que deseja entrar na fila, " + 
							"igual descrito acima.");
							String nome = scanner.nextLine();
							//sistemaInterno.buscadorDeHospitais(nome);
							if (sistemaInterno.buscadorDeHospitais(nome).equals("Sucesso")) {

								hospitalEscolhido = nome;
								
								System.out.println();
								System.out.println("Agora, precisamos que voc� preencha essa ficha de triagem!");
								
								sistemaInterno.triagem();
								
								System.out.println();
								System.out.println();
								System.out.println("Pronto! Voc� est� cadastrado na fila deste hospital");
							} else {
								System.out.println("Erro! Insira corretamente o nome da unidade que deseja entrar na fila de espera!");
							}
						}
						
						if(escolha.equals("2")) {
							break;
						}
					}

				case "2":


					sistemaInterno.mostradorDeFilaDeEspera(hospitalEscolhido);
					break;
					
				case "3":
					
					System.out.println("Seus dados:");
					System.out.println();
					System.out.print("Nome: " + sistemaInterno.getPaciente().getNome());
					System.out.println();
					System.out.print("Data de nascimento: " + sistemaInterno.getPaciente().getDataDeNascimento());
					System.out.println();
					System.out.print("CPF: " + sistemaInterno.getPaciente().getCpfCnpj());
					System.out.println();
					System.out.print("Senha: " + sistemaInterno.getPaciente().getSenha());
					
					System.out.println();					
					System.out.println();					
					
					System.out.println("O que voc� deseja fazer?");
					System.out.println("1- Alterar o nome");
					System.out.println("2- Alterar a data de nascimento");
					System.out.println("3- Alterar sua senha");
					System.out.println("4- Voltar");
			
					String deliberacao = scanner.nextLine();
					
					if(deliberacao.equals ("1")) {
						System.out.println();
						System.out.print("Nome atual: " + sistemaInterno.getPaciente().getNome());
						System.out.println();
						System.out.print("Insira aqui o novo nome: ");
						String nome = scanner.nextLine();
						sistemaInterno.getPaciente().setNome(nome); 
					
					} else if (deliberacao.equals("2")) {
						System.out.println();
						System.out.print("Data De Nascimento atual: " + sistemaInterno.getPaciente().getDataDeNascimento());
						System.out.println();
						System.out.print("Insira aqui a nova data de nascimento nome: ");
						String data = scanner.nextLine();
						sistemaInterno.getPaciente().setDataDeNascimento(data);
						
					} else if (deliberacao.equals("3")) {
						System.out.println();
						System.out.print("Senha atual: " + sistemaInterno.getPaciente().getSenha());
						System.out.println();
						System.out.print("Insira aqui a nova senha: ");
						String senha = scanner.nextLine();
						sistemaInterno.getPaciente().setNome(senha); 
				
					} else if (deliberacao.equals("4")) {
						break;
					}
					
				case "4": 
					saiu = true;
					break;
				}
				
				
			}
		} // fim do if logou paciente, a partir daqui fazemos
			// o desenvolvimento da tela do hospital.

		else if (logouHospital == true) {
			sistemaInterno.cabecalho();
			sistemaInterno.boasVindasHospital();
			sistemaInterno.telaPrincipalHospital();

			Scanner scanner = new Scanner(System.in);
			String decisao = scanner.nextLine();

			sistemaInterno.metodoEscolhas(decisao);

		}
	}
}
