import java.util.ArrayList;

public class FilaDeEspera {

	private ArrayList<Paciente> arrayFilaDeEspera = new ArrayList<>();
	private Paciente paciente;
	private Triagem triagem;
	private int contadorFila = 0;
	private int chamarPessoaParaAtendimento = 0;

	
	public int getNumeroPessoasChamadasParaAtendimento() {
		return this.chamarPessoaParaAtendimento;

	}

	// a corrigir
	public Triagem getTriagem() {
		return triagem;
	}

	//a corrigir
	public void setTriagem(Triagem triagem) {
		this.triagem = triagem;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public int getPosicaoNaFila(int valor) {
		return valor;
	}

	public void adicionarPacientesFilaDeEspera(Paciente paciente) {
		arrayFilaDeEspera.add(paciente);
		this.contadorFila++;

	}

	public void getListaDeEspera() {

		if (arrayFilaDeEspera.size() > 0) {

			System.out.println("Fila de Espera");
			System.out.println("+-+-+-+-+-+-+-+-+-+-+-+-+-+");

			for (int l = 0; l < arrayFilaDeEspera.size(); l++) {

				System.out.printf("||");
				System.out.printf("%14s", String.format("%14s", arrayFilaDeEspera.get(l).getNome()).substring(0, 14));
				System.out.printf("||");
				System.out.printf("%14s", this.getPosicaoNaFila(l + 1));
				System.out.printf("||");
				System.out.printf("%14s", this.getNumeroPessoasChamadasParaAtendimento());
				System.out.printf("||");
				System.out.printf("%14s", arrayFilaDeEspera.get(l).getTriagem().getPerguntaChave());
				System.out.printf("||");
				System.out.printf("%14s", arrayFilaDeEspera.get(l).getTriagem().getEscalaDeDor());
				System.out.println("||");

			}
			System.out.println("+-+-+-+-+-+-+-+-+-+-+-+-+-+");

		} else {
			System.out.println("Nenhum Paciente na Fila de Espera!");
		}
	}

	public int getContadorFila() {
		return this.contadorFila;
	}

}
