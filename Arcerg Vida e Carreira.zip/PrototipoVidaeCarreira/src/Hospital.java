
public class Hospital {

	private Funcionario funcionario;
	private String cep;
	private FilaDeEspera filaDeEspera;
	private String nome;
	private String cnpj;
	private String senhaInstitucional;
	private String senhaPessoalDoResponsavel;
	private Hospital Referencia;
	
	public FilaDeEspera getFilaDeEspera () {
		return this.filaDeEspera;
	}
	
	public Hospital getReferencia() {
		return Referencia;
	}

	public void setReferencia(Hospital referencia) {
		Referencia = referencia;
	}

	public Hospital (String cnpj, String nome, String senhaInstitucional,
			String SenhaDoResponsavel, String CEP ) {
		
		this.cnpj = cnpj;
		this.nome = nome;
		this.senhaInstitucional = senhaInstitucional;
		this.senhaPessoalDoResponsavel = SenhaDoResponsavel;
		FilaDeEspera filaDeEspera = new FilaDeEspera();
		this.filaDeEspera = filaDeEspera;
		this.cep = CEP;
	}
	
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getSenhaInstitucional() {
		return senhaInstitucional;
	}
	public void setSenhaInstitucional(String senhaInstitucional) {
		this.senhaInstitucional = senhaInstitucional;
	}
	public String getSenhaPessoalDoResponsavel() {
		return senhaPessoalDoResponsavel;
	}
	public void setSenhaPessoalDoResponsavel(String senhaPessoalDoResponsavel) {
		this.senhaPessoalDoResponsavel = senhaPessoalDoResponsavel;
	}
	public String getNome () {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
		
	}

	//vai ser usado na hora exibir o numero de pessoa na fila, subtraindo o
	//chamarPessoas....
	public int getNumeroDePessoasNaFila() {
	 return	this.filaDeEspera.getContadorFila();
	}
	public int getNumeroDePessoasChamadas() {
		return this.filaDeEspera.getNumeroPessoasChamadasParaAtendimento();
	}

	public void setFilaDeEspera(FilaDeEspera filaDeEspera) {
		this.filaDeEspera = filaDeEspera;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public String getLocalizacao() {
		return cep;
	}

	public void setLocalizacao(String cep) {
		this.cep = cep;

	}

}
