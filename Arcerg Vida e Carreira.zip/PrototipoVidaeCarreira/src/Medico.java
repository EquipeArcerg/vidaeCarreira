
public class Medico extends Funcionario {

	private Paciente paciente;
}
