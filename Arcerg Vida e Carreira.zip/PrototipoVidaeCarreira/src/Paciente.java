
public class Paciente extends Usuario {
	
	private String senha;
	private Paciente paciente;
	private Triagem triagem;
	private FilaDeEspera filaDeEspera;
	
	
	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Triagem getTriagem() {
		return triagem;
	}

	public void setTriagem(Triagem triagem) {
		this.triagem = triagem;
	}

	public Paciente (String cpf, String nome, String senha, String dataDeNascimento) {
		
		this.senha = senha;
		setCpfCnpj(cpf);
		setNome(nome);
		setDataDeNascimento(dataDeNascimento);
	}
	
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public void setReferencia (Paciente paciente) {
		this.paciente = paciente;
	}

	public Paciente getReferencia () {
		return this.paciente;
}
}
