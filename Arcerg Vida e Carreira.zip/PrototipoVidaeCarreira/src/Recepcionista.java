
public class Recepcionista extends Funcionario {

}
