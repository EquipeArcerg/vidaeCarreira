import java.util.ArrayList;
import java.util.Scanner;

public class SistemaInterno {
	private ArrayList<Paciente> arrayPaciente = new ArrayList<>();
	private ArrayList<Hospital> arrayHospital = new ArrayList<>();

	private boolean buscaBemSucedida;
	private static int numeroDeContasDePacientes;
	private boolean logou;
	private Paciente paciente;
	private Hospital hospital;

	public void cabecalho() {
		System.out.println("--------------------------");
		System.out.println("      Equipe Arcerg	      ");
		System.out.println("--------------------------");

		System.out.println();
		System.out.println();
	}

	public void metodoEscolhas(String decisao) {
		while (true) {
			if (decisao.equals("1") || decisao.equals("2") || decisao.equals("3") || decisao.equals("4")) {

				break;
			} else {
				System.out.println("Op��o invalida!\n");
				System.out.println("Selecione uma op��o valida!\n");
			}
		}
	}

	public ArrayList getPacientes() {
		return arrayPaciente;
	}

	public void adicionarPaciente(Paciente paciente) {
		arrayPaciente.add(paciente);
		numeroDeContasDePacientes++;
		paciente.setNumeroDaConta(this.numeroDeContasDePacientes);
		paciente.setReferencia(paciente);
	}

	public void getListPaciente() {
		if (arrayPaciente.size() > 0) {

			System.out.println("Pacientes Cadastrados");
			System.out.println("+-+-+-+-+-+-+-+-+-+-+-+-+-+");

			for (int l = 0; l < arrayPaciente.size(); l++) {
				System.out.printf("||");
				System.out.printf("%14s", arrayPaciente.get(l).getCpfCnpj());
				System.out.printf("||");
				System.out.printf("%14s", String.format("%14s", arrayPaciente.get(l).getNome()).substring(0, 14));
				System.out.printf("||");
				System.out.printf("%14s", arrayPaciente.get(l).getSenha());
				System.out.printf("||");
				System.out.printf("%14s", arrayPaciente.get(l).getNumeroDaConta());
				System.out.println("||");
				
			}
			System.out.println("+-+-+-+-+-+-+-+-+-+-+-+-+-+");

		} else {
			System.out.println("Nenhum Paciente Cadastrado");
		}

	}

	public boolean login(String cpf, String senha) {
		int l = 0;
		for (l = 0; l < arrayPaciente.size(); l++) {

			if (cpf.equals(arrayPaciente.get(l).getCpfCnpj()) && senha.equals(arrayPaciente.get(l).getSenha())) {

				this.paciente = arrayPaciente.get(l).getReferencia();
				this.logou = true;
			}
		}
		if (this.logou == true) {
			return true;

		} else {
			return false;
		}
	}

	public void boasVindasPaciente() {

		System.out.println("Seja bem vindo, " + this.paciente.getNome());
		System.out.println("CPF: " + this.paciente.getCpfCnpj());
		System.out.println();
		System.out.println();

	}

	public void telaPrincipalPaciente() {
		System.out.println("O que voc� gostaria de fazer?");
		System.out.println();

		System.out.println("1- Visualizar e registrar-se em uma fila de espera de "
				+ "hospitais e unidades de pronto atendimento pr�ximas a voc�.");
		
		System.out.println("2- Ver minha posi��o na fila de Espera ("
				+ "Obrigat�rio j� ter se cadastrado em uma anteriormente!)");
		System.out.println("3- Alterar meus dados ");
		System.out.println("4- Sair ");

		System.out.println();
		System.out.println();
	}

	//
	//
	//

	public boolean loginHospital(String cnpj, String senhaInstitucional, String senhaPessoalDoRespons�vel) {
		int l = 0;

		for (l = 0; l < arrayHospital.size(); l++) {

			if (cnpj.equals(arrayHospital.get(l).getCnpj())
					&& senhaInstitucional.equals(arrayHospital.get(l).getSenhaInstitucional())
					&& senhaPessoalDoRespons�vel.equals
					(arrayHospital.get(l).getSenhaPessoalDoResponsavel())) {

				this.hospital = arrayHospital.get(l).getReferencia();
				this.logou = true;
				break;
			}
		}
		if (this.logou == true) {
			return true;

		} else {
			return false;
		}
	}

	public ArrayList getListadeHospitais() {
		return arrayHospital;

	}

	public void adicionarHospital(Hospital hospital) {
		arrayHospital.add(hospital);
		hospital.setReferencia(hospital);

	}

	// Ainda vai ser corrigido conforme necessidade na hora de mostrar fila de
	// espera.
	public void getListHospitais() {

		if (arrayHospital.size() > 0) {

			System.out.println("Hospitais Cadastrados");
			System.out.println("+-+-+-+-+-+-+-+-+-+-+-+-+-+");

			for (int l = 0; l < arrayHospital.size(); l++) {

				System.out.printf("||");
				System.out.printf("%25s", String.format("%14s", arrayHospital.
						get(l).getNome()));
				System.out.printf("||");
				System.out.printf("%14s", arrayHospital.get(l).
						getNumeroDePessoasNaFila() - 				
						arrayHospital.get(l).getFilaDeEspera 		
						().getNumeroPessoasChamadasParaAtendimento());
				System.out.printf("||");
				System.out.printf("%14s", arrayHospital.get(l).getLocalizacao());
				System.out.println("||");

			}
			System.out.println("+-+-+-+-+-+-+-+-+-+-+-+-+-+");

		} else {
			System.out.println("Nenhum Hospital Cadastrado");
		}
	}

	public void boasVindasHospital() {
		System.out.println("Seja bem vindo!");
		System.out.println("Logado como: " + hospital.getNome());
		System.out.println("CNPJ :" + hospital.getCnpj());
		System.out.println();
	}

	public void telaPrincipalHospital() {
		System.out.println("O que voc� gostaria de fazer?");
		System.out.println();

		System.out.println("1- Gerenciar fila de espera");
		System.out.println("2- Visualizar triagens");
		System.out.println("3- Alterar meus dados [!]");
		System.out.println("4- Sair ");

		System.out.println();
		System.out.println();
	}

	public void triagem() {

		Scanner scanner = new Scanner(System.in);

		System.out.println("Dados do Paciente: ");
		System.out.println(this.paciente.getNome());
		System.out.println(this.paciente.getDataDeNascimento());
		System.out.println();

		System.out.println("Qual o(s) principal(s) sintoma(s) que voc� est� sentindo?");
		String sintomas = scanner.nextLine();
		System.out.println("Em uma escala realista de 0 a 10, quanta dor est� sentindo?");
		String escaladeDor = scanner.nextLine();
		System.out.println("H� traumas, sinais de problema cardiovascular ou cerebral? ");
		String perguntaChave = scanner.nextLine();

		Triagem triagem = new Triagem();
		this.paciente.setTriagem(triagem);
		triagem.setSintomas(sintomas);
		triagem.setEscalaDeDor(escaladeDor);
		triagem.setPerguntaChave(perguntaChave);

		System.out.println("Respostas salvas!");
	}

	
	public int buscarHospital (String nome) {
		for (int i = 0; i < arrayHospital.size(); i++) {
			if (nome.equals(arrayHospital.get(i).getNome())) {
				return i;
			}
		}
		return -1;
	}
	
	
	
	
	
	
	public String buscadorDeHospitais (String nome) {
		for (int l = 0 ;  l < arrayHospital.size(); l++) {
			
			if(nome.equals(arrayHospital.get(l).getNome())){
				
				arrayHospital.get(l).getFilaDeEspera()
				.adicionarPacientesFilaDeEspera(paciente);
				
				this.buscaBemSucedida = true;
				
				
			}  
			
			
		}
		if (this.buscaBemSucedida == true) {
			return "Sucesso";
		} else {
			return "Erro, digite corretamente o nome do hospital!";
		}
	}
	
	public void mostradorDeFilaDeEspera (String nomeDoHospital) {
for (int l = 0 ;  l < arrayHospital.size(); l++) {
			
			if(nomeDoHospital == arrayHospital.get(l).getNome()) {
			
				arrayHospital.get(l).getFilaDeEspera().getListaDeEspera();
			} else {
				
			}
	}
	
}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
}