
public class Triagem {

	private String sintomas;
	private String escalaDeDor;
	private String perguntaChave;
	
	
	public String getSintomas() {
		return sintomas;
	}
	public void setSintomas(String sintomas) {
		this.sintomas = sintomas;
	}
	public String getEscalaDeDor() {
		return escalaDeDor;
	}
	public void setEscalaDeDor(String escalaDeDor) {
		this.escalaDeDor = escalaDeDor;
	}
	public String getPerguntaChave() {
		return perguntaChave;
	}
	public void setPerguntaChave(String perguntaChave) {
		this.perguntaChave = perguntaChave;
	}
	
	
}
